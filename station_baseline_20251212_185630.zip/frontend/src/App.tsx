import StationConsole from "./StationConsole";

export default function App() {
  return <StationConsole />;
}
