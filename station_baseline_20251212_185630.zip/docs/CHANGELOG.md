# Changelog

## r9600
- Stable Station baseline (backend + frontend).
- Settings persistence (LocalStorage + optional backend).
- Ops endpoints gated by Edit Mode Key.
- GitHub ops: status + stage/commit/push pipeline.
- Render key placeholders + service hooks (ready for wiring).
- External LLM key slot integrated via settings.
- Baseline Rooms/Guards structure (needs tightening in next rev).
