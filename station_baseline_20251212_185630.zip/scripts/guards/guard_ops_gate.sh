#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
bash scripts/guards/guard_tree_bindings.sh
