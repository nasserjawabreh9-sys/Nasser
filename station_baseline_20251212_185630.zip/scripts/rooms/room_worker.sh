#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
# Skeleton: future worker reads tasks.jsonl and executes room-specific steps with locks.
echo "ROOM_WORKER_STUB"
