#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
# Skeleton: future dispatcher assigns tasks to rooms; ensures guards + locks + merge.
echo "DISPATCH_STUB"
